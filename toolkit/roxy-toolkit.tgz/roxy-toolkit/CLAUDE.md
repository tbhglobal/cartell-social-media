# CarTell.tv — project rules

Every deliverable for CarTell.tv (websites, posts, presentations, ads, docs, internal tools, anything visual or written) must follow this brand system. The canonical source is `brand-guide.html` in this folder, with a printable `CarTell-brand-guide.pdf` alongside it. When in doubt, open those first.

## Hard rule — no post ships without a verified hero image

Every published entry on cartell.tv (news, review, e-bike post, anything that becomes a card or a page) must have a real, verified hero image before it goes live. This is a publish gate, not a preference.

- **A verified image is required to publish.** "Verified" means the file or URL actually loads, and for a local path the file exists and is non-zero bytes, and for a remote URL the host is in the `next.config` allowlist. No guessing, no placeholder URLs.
- **If no hero can be verified, the post does not publish.** Hold it in the backfill queue until an image is sourced. Do not publish image-less and rely on the branded fallback tile.
- **The branded fallback is an emergency net, not an acceptable published state.** If you can see the gradient "CarTell.tv" tile on a live card, that post is broken and needs an image now. It is not "done".
- **Omit beats broken still holds, but omit now means hold, not ship.** Never write a broken or unverified `image:` field. If you would have to omit it, the post is not ready to publish.
- **Source images yourself.** Use manufacturer or press media directories and the existing sourcer pipelines first. Never ask Ted to download images manually, and never ship text-only to "fix it later".

This rule exists because images have repeatedly shipped missing and surfaced as fallback tiles on the homepage. A written rule alone has not been enough: the publish path (`_agent_shared/cartell-publish.sh`) must enforce it by rejecting any new entry that lacks a verified hero. See the publish-gate note in the agent briefs.

## Hard rule — product images on pure white only

Every vehicle, bike, or product hero and card image must sit on a pure white background (RGB 255, 255, 255) or a transparent one. This is a publish gate, same standing as the verified-hero rule.

- **Pure white, not near white.** A light grey studio background (for example RGB 241, which reads as a grey box on a white card) is not acceptable. Confirm the four corners of the image read 255, 255, 255 before publishing.
- **The whole product must be in frame.** A rear wheel, a drivetrain close-up, or a bike with the handlebars cut off is not a hero, even on a perfect white background. The corner check does not catch this, so the image has to be looked at. Manufacturers publish detail shots on white and they will pass every automated test.
- **No coloured, grey, or black studio backgrounds**, and never a storefront, showroom, or lifestyle photo as the catalogue image. The subject is the product, cut out on white.
- **If a sourced shot has a grey or black background,** clean the background to white only when the subject does not blend into it (a dark bike on a black background cannot be cleaned this way and enclosed frame areas stay dark). Otherwise source a clean white-background image instead.
- **When in doubt, hold the entry** rather than ship a grey or black tile. Omit beats broken, and a grey box beats nothing only in that it still fails this gate.

This rule exists because grey and black-background product shots have repeatedly shipped and appeared as grey or dark boxes on otherwise white directory cards.

## Hard rule — git safety for every agent that pushes

Several agents push to `CarTell-tv/cartell-tv` `main` every day (cloud news desk, Chief of Staff, directory sweeps, e-bike and BikeFinder work).

- **Never force-push `main`** (`--force`, `--force-with-lease`, `+main`). A force-push silently deletes other agents' commits.
- Push rejected: fetch and rebase onto `FETCH_HEAD`. If the rebase hangs or conflicts on files you did not touch, abort, check out `FETCH_HEAD` detached, cherry-pick your one commit, push normally.
- News and reviews (`lib/reviews.ts`) publish only through `_agent_shared/cartell-publish.sh`.
- Keep the GitHub token out of printed output and logs (redact `ghp_` strings). A leaked token gets auto-revoked and blocks every agent.
- Check `_agent_shared/AGENT-MAP.md` for who owns a job or file before starting work on it.

## Before producing any CarTell.tv deliverable

1. Read this file in full.
2. Use the assets in `/brand/` for the logo. Never redraw or recolor the mark.
3. Stay inside the design tokens listed below. If a value isn't here, it isn't on brand.
4. For any externally-shared text (posts, ads, captions, decks), apply the "no dashes as punctuation" rule from the user's memory.

## Logo

Use the original CarTell.tv mark. Three primary files, all in `/brand/`:

- `cartell-mark-original.png` — gradient bubble + car + play. Use on light backgrounds, snow surfaces, and as the icon when paired with the wordmark inline.
- `cartell-logo-vertical.png` — full stacked lockup (mark + "CarTell.tv" wordmark). Use when the brand needs to read at a glance and there is vertical room.
- `cartell-mark-white-knockout.png` — white silhouette with knocked-out interior. Use on dark backgrounds, on the gradient, on photography, anywhere the gradient would lose contrast.

For a horizontal lockup, compose inline: place the mark image next to "CarTell.tv" set in Sofia (or Sofia Sans) 800 italic, letter-spacing −0.02 to −0.03em, color Ink (#0B1220) on light or Pure (#FFFFFF) on dark.

Never: rotate, skew, recolor the gradient, stretch, place the gradient mark on conflicting hues (yellow, lime, cyan), or add effects (drop shadows, glows, outlines).

## Color

Primary gradient (the lead color, the one the brand owns):
```
linear-gradient(135deg, #B81FD8 0%, #E3187C 55%, #F0185C 100%)
```

Brand solids:
- Magenta `#B81FD8`
- Hot Pink `#E3187C`
- Rose `#F0185C`

Neutrals:
- Ink `#0B1220` — primary text
- Carbon `#1A2335` — dark surfaces
- Slate `#3D4858` — body text
- Steel `#6B7689` — captions, meta
- Mist `#C9D0DC` — strong borders
- Cloud `#ECEEF3` — subtle borders
- Snow `#F7F8FB` — light surfaces
- Pure `#FFFFFF` — canvas

Functional (system meaning only, not decoration):
- Live `#FF3052` — broadcast indicator only
- Signal `#00E0B2` — success, fresh data
- Caution `#FFB020` — warning
- Alert `#FF4A4A` — critical

Never invent off-system colors. If something needs a new color, that's a brand decision, not a styling one.

## Typography

The brand voice on the page is Sofia Pro. For web fall back to Sofia Sans (Google Fonts), then Inter, then system sans.

Two roles, two styles, that's it:

- Display & headlines → Sofia 800 italic (Bold Italic). Letter-spacing tightens with size, from −0.01em at h3 to −0.03em at display.
- UI, body, captions → Sofia 500 (Medium), roman, no italic.

Type scale (use these, not other sizes):
- Display XL: 72/72px, 800 italic, −0.03em
- Display: 48/50px, 800 italic, −0.025em
- H1: 36/40px, 700 italic, −0.02em
- H2: 28/34px, 700 italic, −0.015em
- H3: 20/26px, 700 roman
- Body L: 18/28px, 500 roman
- Body: 16/26px, 500 roman
- Caption: 14/21px, 500 roman
- Micro: 11px, 700, 0.16em letter-spacing, uppercase (used for eyebrows and section labels)

Never set body text in italic. Never mix bold roman with italic display in the same line.

## Spacing & radius

Stick to the 4px grid: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128.

Radii: 4 (xs), 8 (sm), 12 (md), 20 (lg), 32 (xl), 999 (pill). Buttons are always pill. Cards are usually lg. Tags are xs.

## Motion

Three durations only:
- Fast: 120ms (micro-interactions)
- Standard: 200ms (most transitions)
- Confident: 320ms (page-level reveals)

One easing curve only: `cubic-bezier(0.2, 0.8, 0.2, 1)`.

## Voice & tone

Talk like a driver, write like an editor. Direct, specific, in on the joke. Confident without bravado. Numbers and trim levels where they help. Active verbs. No hype.

Say: "Three days, 600 miles, one charge stop. Here is the math."
Not: "You will not believe how far this EV went in our shocking road trip test."

**Hard rule — no long dashes in any public-facing content.** This applies to everything a person outside TBH Global can see: social posts, captions, video scripts, on-screen text, titles, ads, emails, website copy, decks, press releases, and any other media. Em dashes (—) and en dashes (–) are banned. Hyphens used as punctuation (i.e. as a dash, not as a compound word connector) are also banned. Use commas, periods, parentheses, or colons instead. There are no exceptions for style or emphasis.

## Components

- Buttons: pill shape (`border-radius: 999px`), 12px × 22px padding, 700 weight. Primary uses the gradient with a soft pink-magenta drop shadow. One primary button per view, maximum.
- Tags: 4px × 10px padding, 11px, 700, 0.12em letter-spacing, uppercase. Live tag pulses (1.4s ease in/out).
- Cards: 1px Cloud border, radius lg, padding 32px (or 24px for tight layouts).
- Live indicator: only for genuine on-air broadcasts. Never for "new" or "trending."

## Files & where things live

```
/CarTell.tv/
├─ CLAUDE.md                         ← this file
├─ brand-guide.html                  ← canonical brand guide (open this first)
├─ CarTell-brand-guide.pdf           ← printable version
└─ brand/
   ├─ cartell-mark-original.png      ← gradient mark, light backgrounds
   ├─ cartell-logo-vertical.png      ← stacked lockup
   └─ cartell-mark-white-knockout.png ← white mark for dark / gradient
```

The originals (`CARTELL icon.png`, `cartell horizontal.png`, `Cartell icon white.png`, etc.) also live at the project root and remain valid source files.

## Quick checklist

Before considering any CarTell.tv deliverable done:
- [ ] Logo used from `/brand/`, not redrawn
- [ ] Colors from the system above only
- [ ] Sofia (or Sofia Sans) used everywhere
- [ ] One primary action per view
- [ ] Spacing on the 4px grid
- [ ] No em dashes, en dashes, or hyphens-as-punctuation anywhere in the output
- [ ] If creating a new component, check `brand-guide.html` first
