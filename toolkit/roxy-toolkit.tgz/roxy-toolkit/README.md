# Roxy toolkit (cloud copy)

Everything a cloud social agent needs that used to live only on Ted's Mac.

- CLAUDE.md: CarTell.tv brand and publishing rules (no dashes, pure white product shots, verified heroes).
- CADENCE.md, BUDGET-RULES.md: posting cadence, slots and spend rules.
- brands/<brand>.md: one brief per brand (accounts, voice, tags, what to avoid).
- briefs/: the last three week briefs. 2026-10-13-WEEK-BRIEF.md is the current pattern.
- build/<brand>/: the Python build scripts that made the last week of posts for each brand (PIL). Paths inside point at the old Mac folder: change BASE/paths to your working folder.
- build/cartell-lib/lib.py: CarTell tile library (tile, window, cover, payoff).
- build/scootfinder/: ScootFinder tile and reel library.
- fonts/: every font the brands use. logos/ and brand-assets/: logos and mascots.
- tools/qa_check.py: the QA script (dashes, white corners, repeats).

Media hosting from the cloud: insert into public.social_media_inbox (path, b64, content_type) or (path, source_url) using the Supabase connector. A trigger uploads it and fills the url column with a public link under scheduler-media/cloud/. Use that url in sched_posts.media_urls.
