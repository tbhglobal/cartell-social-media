#!/usr/bin/env python3
"""Roxy pre-flight QA for a week of social drafts.

Usage: python3 qa_check.py <week_dir>   (e.g. .../drafts/2026-09-28)

Runs the mechanical checks automatically and writes QA-REPORT.md plus one
full-width review strip per post (qa/<brand>-<day>.jpg) for the human-eye pass.
Anything flagged FAIL must be fixed before Ted sees it. REVIEW items need Roxy to
look and decide. Passing this script is necessary, not sufficient.
"""
import sys, os, re, json, glob, subprocess, datetime
from PIL import Image, ImageDraw
import cv2, numpy as np
_ORB = cv2.ORB_create(1500); _BF = cv2.BFMatcher(cv2.NORM_HAMMING)


def orb_feats(path):
    im = cv2.imread(path, 0); h = im.shape[0]
    return _ORB.detectAndCompute(im[int(h * .10):int(h * .45)], None)  # photo band, clear of logo and text panel


def same_photo_score(a, b):
    """RANSAC inliers between two slides' photo bands. Catches the same photo recropped or zoomed.
    Calibrated 26 Sep 2026: different photos score under 30, the same photo 150 to 1100."""
    (ka, da), (kb, db) = a, b
    if da is None or db is None: return 0
    good = [p[0] for p in _BF.knnMatch(da, db, k=2) if len(p) == 2 and p[0].distance < 0.75 * p[1].distance]
    if len(good) < 8: return len(good)
    src = np.float32([ka[g.queryIdx].pt for g in good]); dst = np.float32([kb[g.trainIdx].pt for g in good])
    _, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
    return int(mask.sum()) if mask is not None else 0

WEEK = sys.argv[1]
TODAY = datetime.date.today()
RIVALS = ['carexpert', 'drive.com.au', 'whichcar', 'carsguide', 'wheels mag', 'motor mag',
          'bicycling australia', 'bikeradar', 'cyclingnews', 'cycling weekly', 'ozbike']
AI_HINTS = ['artlist', 'generat', 'ai ', 'illustrative', 'nano banana', 'seedance', 'kling', 'seedream']


def dhash(im, size=16):
    g = im.convert('L').resize((size + 1, size), Image.LANCZOS)
    px = list(g.getdata()) if not hasattr(g, 'get_flattened_data') else list(g.get_flattened_data()); bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (px[r * (size + 1) + c] > px[r * (size + 1) + c + 1])
    return bits


def ham(a, b): return bin(a ^ b).count('1')


def photo_region(im):
    # the photo usually fills the top part of a slide; compare that part only
    w, h = im.size
    return im.crop((0, int(h * 0.08), w, int(h * 0.55)))


def frames(mp4, n=6):
    d = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', mp4]))
    out = []
    for i in range(n):
        t = 0.4 + (d - 0.8) * i / (n - 1); o = f'/tmp/qa_{os.getpid()}_{i}.jpg'
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', f'{t:.2f}', '-i', mp4, '-frames:v', '1', o])
        if os.path.exists(o): out.append((t, Image.open(o).convert('RGB')))
    return d, out


def vol(mp4):
    r = subprocess.run(['ffmpeg', '-i', mp4, '-af', 'volumedetect', '-f', 'null', '-'], capture_output=True, text=True).stderr
    m = re.search(r'mean_volume: (-?[\d.]+)', r); return float(m.group(1)) if m else -99


report = ['# QA report: ' + os.path.basename(WEEK.rstrip('/')), '']
os.makedirs(os.path.join(WEEK, 'qa'), exist_ok=True)
totals = {'FAIL': 0, 'REVIEW': 0}
for mf in sorted(glob.glob(os.path.join(WEEK, '*/manifest.json'))):
    bdir = os.path.dirname(mf); brand = os.path.basename(bdir)
    data = json.load(open(mf)); posts = data if isinstance(data, list) else data['posts']
    report.append(f'## {brand}')
    for p in sorted(posts, key=lambda x: x.get('day', '')):
        issues = []
        media = p.get('media') or []
        media = [media] if isinstance(media, str) else media
        paths = []
        for f in media:
            cand = [os.path.join(bdir, f), os.path.join(bdir, 'final', os.path.basename(f))]
            path = next((c for c in cand if os.path.exists(c)), None)
            if not path: issues.append(('FAIL', f'missing media file {f}'))
            else: paths.append(path)
        text = ' '.join(str(p.get(k, '')) for k in ('caption_instagram', 'caption_facebook', 'hook'))
        meta = json.dumps(p, ensure_ascii=False).lower()
        if re.search(r'[—–]| - ', text): issues.append(('FAIL', 'dash used as punctuation in caption or hook'))
        for r in RIVALS:
            if r in text.lower(): issues.append(('FAIL', f'rival outlet named in caption: {r}'))
        if re.search(r'\bUSD\b|US\$', text): issues.append(('FAIL', 'USD pricing in caption'))
        for dstr in re.findall(r'20\d\d-\d\d-\d\d', json.dumps(p.get('sources', ''))):
            try:
                if (TODAY - datetime.date.fromisoformat(dstr)).days > 7: issues.append(('REVIEW', f'source checked {dstr}, over 7 days old'))
            except ValueError: pass
        is_ai = any(h in json.dumps(p.get('image_sources', '')).lower() for h in AI_HINTS)
        named_place = bool(re.search(r'\b(where|trail|lake|park|beach|river|bridge|parade|harbour|marina)\b', text.lower()))
        if is_ai and named_place: issues.append(('REVIEW', 'AI imagery on a post that names a real place: confirm it is not a fake version of a recognisable location, else source real photos'))
        # image checks
        hashes = []
        strip = []
        for path in paths:
            if path.endswith('.mp4'):
                d, fr = frames(path)
                w, h = fr[0][1].size if fr else (0, 0)
                if (w, h) != (1080, 1920): issues.append(('FAIL', f'reel is {w}x{h}, not 1080x1920'))
                if not 12 <= d <= 35: issues.append(('REVIEW', f'reel length {d:.1f}s'))
                v = vol(path)
                if v < -30: issues.append(('FAIL', f'reel audio silent or near silent ({v} dB)'))
                fh = [dhash(im) for _, im in fr]
                same = sum(1 for i in range(len(fh) - 1) if ham(fh[i], fh[i + 1]) < 12)
                if same >= len(fh) - 2: issues.append(('FAIL', 'reel barely changes between sampled frames (static)'))
                strip += [im for _, im in fr]
            else:
                im = Image.open(path).convert('RGB')
                if im.size not in [(1080, 1350), (1080, 1080), (1080, 1920)]: issues.append(('FAIL', f'{os.path.basename(path)} is {im.size}'))
                hashes.append((os.path.basename(path), orb_feats(path))); strip.append(im)
        for i in range(len(hashes)):
            for j in range(i + 1, len(hashes)):
                sc = same_photo_score(hashes[i][1], hashes[j][1])
                if p.get('step_series') and sc >= 60: issues.append(('REVIEW', f'step series (same subject by design): {hashes[i][0]} and {hashes[j][0]} (match {sc})')); continue
                if sc >= 150: issues.append(('FAIL', f'same photo reused: {hashes[i][0]} and {hashes[j][0]} (match {sc})'))
                elif sc >= 60: issues.append(('REVIEW', f'possibly the same photo: {hashes[i][0]} and {hashes[j][0]} (match {sc}); fine only for a deliberate step by step series'))
        if strip:
            H = 900; tiles = [s.resize((int(s.width * H / s.height), H)) for s in strip]
            M = Image.new('RGB', (sum(t.width for t in tiles) + 16 * len(tiles), H), 'white'); x = 0
            for t in tiles: M.paste(t, (x, 0)); x += t.width + 16
            M.save(os.path.join(WEEK, 'qa', f"{brand}-{p.get('day', 'x')}.jpg"), quality=85)
        status = 'FAIL' if any(s == 'FAIL' for s, _ in issues) else ('REVIEW' if issues else 'PASS')
        if status != 'PASS': totals[status] += 1
        report.append(f"- **{status}** {p.get('day')} {p.get('type')}: {p.get('hook', '')}")
        for s, msg in issues: report.append(f'  - {s}: {msg}')
    report.append('')
report.insert(1, f"Posts failing: {totals['FAIL']}. Posts needing review: {totals['REVIEW']}.\n")
report.append('## Human eye pass (always, after the script)')
report += ['- Open every strip in qa/ at full size. Check each slide adds something new, the product or place is real and whole, text reads at phone size, no empty half panels, nothing fake passing as a real model or place, helmets, AI errors (limbs, wheels, floating objects).']
open(os.path.join(WEEK, 'QA-REPORT.md'), 'w').write('\n'.join(report))
print('\n'.join(report[:3]))
