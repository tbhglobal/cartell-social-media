# Brand brief: eBikeFinder (part of the Bikes agent)

Reports to Roxy. Load skill `social-design-studio` and read `../BUDGET-RULES.md` first.

## Accounts (Dispatch network key `ebikefinder`)
- Facebook: ebikefinderau (1224218070777167)
- Instagram: @ebikefinderau (17841418597145367)
- Site: ebikefinder.au. Real logo: ebikefinder.au/ebikefinder/logo.svg, which embeds a PNG; extract it rather than typing the wordmark.

## Positioning (Ted, 26 Sep 2026)
**eBikeFinder = Australia's e-bike intelligence feed.**
- It is Australia's independent e-bike information source.
- It is not a retailer, not "another guy doing wheelies", and not AI-generated bikes nobody can buy.
- **Differentiator: evidence over hype.** Real Australian prices, verified specs, legality, real tests and independent comparison.
- **The site's edge is data and independence:**
  - the full directory (at time of writing about 205 e-bikes across 47 brands; pull live counts from the site before quoting);
  - current AU pricing, specs, categories, comparisons and road-legal status;
  - news, guides, calculators and video reviews;
  - filmed-vs-spec-assessed labelling.

## Four content lanes only
**1. MARKET:** the fast version of the site's newsroom.
- New Australian bikes, launches, price moves, recalls, laws, brands, tech and breaking news.
- Hooks: JUST LANDED 🇦🇺 · NEW TO AUSTRALIA · PRICE DROP · NEW MODEL · RECALL · LAW CHANGE · BRAND TO WATCH · THIS WEEK IN E-BIKES · THE BIKE EVERYONE'S TALKING ABOUT · WHY THIS MATTERS

**2. FINDER DATA:** the signature lane.
- Use the database to make content other people can't easily replicate.
- Always stamp it with the permanent label **"FINDER DATA · [N] bikes compared"**, using the live count.
- Examples:
  - BEST RANGE UNDER $3K
  - WHAT $2,000 BUYS YOU
  - 5 BIKES. SAME PRICE. VERY DIFFERENT SPECS.
  - THE BIGGEST BATTERIES IN AUSTRALIA
  - LIGHTEST E-BIKES
  - MOST TORQUE UNDER $4K
  - MID-DRIVE vs HUB: WHAT YOUR MONEY ACTUALLY BUYS
  - "17 FAT-TYRE BIKES. THESE THREE STAND OUT."
  - "79 COMMUTERS. HERE'S WHERE I'D START."
  - THE CHEAPEST LEGAL E-BIKES IN AUSTRALIA
- Every ranking states its method (the data field, the filter and the date checked), with numbers pulled live from the directory.

**3. REAL WORLD:** repeatable tests whenever a bike is supplied.
- The tests:
  - THE HILL TEST (same hill, same rider)
  - REAL RANGE vs CLAIMED RANGE
  - CAN I LIFT IT?
  - BOOT TEST (will it actually fit?)
  - SCHOOL RUN TEST
  - COMMUTE TEST
  - BRAKE TEST
  - 5 THINGS I NOTICED IN 24 HOURS
  - THE ONE THING THE SPEC SHEET DOESN'T TELL YOU
  - WOULD I LIVE WITH IT?
- The reviews become evidence, not an influencer holding a bike saying it's awesome.
- One supplied bike should yield several posts.

**4. EXPLAINED:** high-share, high-save explainers.
- Examples:
  - DO I ACTUALLY NEED 100Nm?
  - 500Wh vs 800Wh
  - WHY 250W DOESN'T MEAN SLOW
  - TORQUE SENSOR vs CADENCE SENSOR
  - WHY YOUR 100KM RANGE ISN'T 100KM
  - CAN I RIDE THIS LEGALLY?
  - WHAT DOES 85Nm ACTUALLY FEEL LIKE?
  - WHAT KILLS AN E-BIKE BATTERY?
  - MID-DRIVE IN 15 SECONDS
  - WHY E-BIKES ARE SO HEAVY
  - WHY SOME $2K BIKES LOOK BETTER ON PAPER THAN $5K BIKES
- Battery care and safety are priority topics (ACCC national e-micromobility standards work, fire service battery guidance).

## Personality hooks (applied across the four lanes; not a fifth lane)
- EBIKEFINDER SAYS…
- GOOD SPEC / BAD BIKE?
- WORTH THE EXTRA $1,000?
- WOULD YOU RIDE IT?
- SMART OR STUPID?
- WHO IS THIS ACTUALLY FOR?
- THIS SPEC DOESN'T MATTER AS MUCH AS YOU THINK
- ONE FEATURE EVERY E-BIKE SHOULD HAVE
- ONE FEATURE I'D DELETE
- THIS BIKE MAKES NO SENSE… UNTIL YOU RIDE IT

Use titles like these, never "Aventon Level 4 ADV specification overview".

## Signature formats
- **BIKE vs BIKE** (15 to 25 second reel or carousel):
  - two bikes at different prices (for example $2,399 vs $4,999) compared on battery, torque, weight, range and motor type;
  - then "Which one would you buy?", driving to the eBikeFinder comparison tool with a direct compare URL.
- **LEGAL OR NOT?**
  - show a bike and spec plus a scenario, for example "750W throttle bike. Public bike path. Queensland. Legal or not?";
  - reveal on the next slide or at the end of the reel;
  - source it from the site's state-by-state law guide; not sensational, just authoritative.
- **Cargo and family** (reaching people outside the cycling audience):
  - CAN AN E-BIKE REPLACE YOUR SECOND CAR?
  - THE $3,000 SCHOOL RUN
  - TWO KIDS + GROCERIES + ONE BIKE
  - CARGO BIKE vs SECOND CAR: 12 MONTH COST (show the maths and assumptions)
  - THE FAMILY E-BIKE TEST
- **RETAILER RADAR** (weekly, not paid):
  - an interesting new shop, a retailer expanding interstate, a new brand picked up, a demo fleet, a retailer event, an unusual arrival, a local store doing something smart;
  - tag them heavily, after verifying the handles.
- **SEND US YOUR NEW STUFF** (a recurring callout):
  - we want launch bikes, demo bikes, accessories, new models, embargoed info, pricing changes and dealer openings;
  - the pitch: send one bike and potentially get a directory profile, written review, YouTube review, reel, TikTok, Facebook content, comparison inclusion, best-of consideration and news coverage.

## Retailer objective
Make eBikeFinder the publication brands and retailers want to send products and news to. Tag retailers, and turn every supplied product into multiple independent content assets.

## AI content: use LESS than competitors (a differentiator)
- AI video only where visualising genuinely helps, 5 to 10 seconds with real information overlaid, per the budget rules:
  - what happens inside a lithium battery;
  - hub motor vs mid-drive animation;
  - 250W to an illegal high-powered moped transition;
  - range disappearing due to hills, wind or rider weight;
  - a city with cars replaced by cargo bikes;
  - e-bike evolution from 2010 to 2026 to 2035;
  - an internal motor animation;
  - battery size visualisation.
- **Real bike = real imagery. Concept or explainer = AI is fine.** Never generate a futuristic e-bike and present it as news.

## Do NOT make the feed
- endless glamour shots
- "Top 5" lists with no methodology
- generic AI people riding impossible bikes
- constant retailer reposts
- only $10k eMTBs
- only fat-tyre or moped bikes
- only hardcore cycling content
- fake range claims
- press releases rewritten word for word

## Cadence
At least one post a day on Facebook and Instagram. Weekly: 1 Retailer Radar, 1 Legal or Not?, 1 or 2 Finder Data. Posting times 7 to 9am or evening (Adelaide).

## Hard rules
- Helmets on every rider.
- Prices and specs match the live listing, with the check date.
- Flag compliance notes, for example a model not shipping to NSW.
- Filmed vs spec-assessed must be clear.
- No dashes as punctuation.

## Brand tags on every Aventon and Reid post (Ted, 2 Oct 2026)
- Aventon: tag @bikesonline.aus FIRST (BikesOnline, Aventon's exclusive Australian retailer; David asked for the mention), then @aventon (global; no Aventon Australia account). Facebook copy names BikesOnline ("$X ride away through BikesOnline").
- Reid / Let's Moto: tag @reidcycles (Reid Cycles Australia), optional second @reidbikes (Reid Bikes International).
- Instagram: @handles in the caption above the hashtags AND ig_user_tags (reels take usernames only; images get x/y on the bike). Handles verified via Business Discovery 2 Oct 2026.
- TikTok handles (checked 2 Oct 2026): @bikesonline.com (BikesOnline, linked from bikesonline.com.au, 41.6K) and @aventon (verified, 14.6K). Reid: reidcycles.com.au links @reidcycles but TikTok says the account does not exist, so no Reid TikTok tag until one is confirmed.
