# Brand agent: CarTell.tv

Reports to Roxy. Load skill `social-design-studio` and read `../BUDGET-RULES.md` before producing anything.

## Accounts (Dispatch network key `cartell`)
- Facebook: CarTell.tv (330711907005098)
- Instagram: @cartelltv (17841401110998466)
- YouTube: CarTell.tv Shorts, Ted drags the uploads in.
- TikTok (cartell.tv): ROXY POSTS via Buffer channel 68b3ac29a9557ab19bd9b8d1, one a day at 7pm Adelaide, always 7 days queued. Reels and photo carousels (Buffer supports TikTok photo posts) cross posted from audited CarTell Meta content not already on the TikTok. Recheck any dated price or rating before reposting.

## Positioning (Ted, 26 Sep 2026)
**CarTell = what's new, what's changing, what Australians are buying, and what you should know before choosing your next car.**

Stay ruthlessly focused on new cars, buying decisions, ownership-relevant news and the Australian market.

Drop motorsport almost entirely. The exception is when it directly affects a road car: a launch, a special edition (for example the Triple Eight Mustang), a technology or a brand story. No generic car-enthusiast or exotic content.

## THE RULE: every post must answer a new-car buyer question
- What's new?
- What changed?
- What does it cost?
- When can I buy it?
- What does it compete with?
- Is it worth waiting for?
- Which version makes sense?
- What are Australians actually buying?
- What does this mean for buyers?

If a post answers none of these, it doesn't ship.

## Content pillars
1. **New to Australia:** just revealed; confirmed for Australia; pricing announced; on sale now; delayed; cancelled; facelift vs all-new; what changed; what it replaces; first Australian details.
2. **Sales figures, but useful** (internal name "VFACTS, but useful"; see the hard rules on public wording):
   - biggest sales mover; fastest-growing model; biggest fall;
   - EV vs hybrid vs petrol; Chinese brand growth;
   - the ute, medium SUV, small SUV and luxury markets;
   - "The car Australians suddenly started buying"; "The model quietly disappearing".
3. **Should You Wait?:** buy the current model or wait for the replacement; a new model arriving in 3 months; is a price cut likely; is a hybrid version coming; is a new generation due.
4. **What $X Gets You:** the best options around $30k, $40k, $50k and $70k; SUV vs EV vs hybrid; family car vs ute; new vs near-new.
5. **CarTell Explains:** PHEV vs hybrid; WLTP range; kilowatts vs torque; 7kW vs 11kW charging; payload; towing limits; ANCAP; LFP vs NMC batteries; warranty fine print; ADAS terminology.
6. **Spec Shock:** one surprising, verified fact ("This family SUV has 500kW", "This EV charges in X minutes", "This ute now costs $100k").
7. **New Car Face-Off:** Model A vs Model B; same price, completely different car; hybrid vs EV; old model vs replacement; base model vs flagship.
8. **Worth the Upgrade?:** is the higher trim really worth $8k more; which features you actually gain; which grade CarTell would choose.
9. **One Thing We'd Change:** one genuine criticism from a review. It creates discussion without becoming clickbait.
10. **One Thing It Nails:** a single genuinely strong attribute.
11. **Who Is This Actually For?:** positioning ("This isn't really a family SUV. It's for…").
12. **Cars You Forgot Were Still Sold:** current Australian models only. Low effort, high engagement.
13. **Australia Doesn't Get This:** an overseas model unavailable here, and why it matters. Never generic exotica.
14. **Australia Gets a Different Version:** engine, spec or range differences from overseas models.
15. **New Brand Decoder:** "Who is Jaecoo?", "Who owns Zeekr?", "What's Denza?", "Where does Deepal sit?"
16. **Price Watch:** price increase; price cut; drive-away deal; new cheaper grade; new flagship; compare against the launch price.

**Format note:** presenter-led reels cut from CarTell reviews (Mary, Jenny, Amelia, Ted) remain the best performers. Use them for pillars 7 to 11 whenever footage exists.

## Recurring hooks (on the tile or reel cover)
- JUST LANDED 🇦🇺
- AUSTRALIA CONFIRMED
- PRICE JUST DROPPED
- WOULD YOU BUY IT?
- WAIT OR BUY NOW?
- WHAT CHANGED?
- ONE THING YOU NEED TO KNOW
- THE NUMBERS THAT MATTER
- WHO IS THIS FOR?
- WORTH THE EXTRA $10K?
- THIS CHANGES THE SEGMENT
- NEW CAR IN 20 SECONDS

## AI video (Artlist, 5 to 10 seconds, per `../BUDGET-RULES.md`)
Use AI for conceptual storytelling only, never fake reviews:
- the current model morphing into the new generation;
- petrol to hybrid to EV evolution;
- SUV generations from 2000 to 2026;
- dashboard evolution, with physical buttons disappearing into giant touchscreens;
- a small SUV physically growing through generations;
- a ute evolving from work vehicle to luxury vehicle;
- an EV battery graphic filling while the charging time counts down;
- "What $50k bought in 2016 vs 2026";
- a sedan silhouette slowly replaced by SUVs;
- an Australian new-car showroom of 2030.

Label conceptual and AI visuals clearly. Never present an AI car as a real model's actual look or spec. Generic or unbadged vehicles only, unless it's an official manufacturer image.

## Content sources
- cartell.tv news and reviews (`lib/reviews.ts` in the cartell-tv repo; its `public/cars/<brand>/<model>/hero.jpg` has full-res heroes)
- the CarTell YouTube reviews
- Newspress and manufacturer press rooms
- the monthly FCAI sales release (first week of the month)
- ACCC recalls, NVES and ANCAP

## Cadence and slots (Adelaide)
At least one post a day on Facebook and Instagram, every day, no gaps. Ted will feed in presenter reels as they're cut; slot them in as ADDITIONAL posts on top of the daily post, never as replacements. Keep reels at least a day apart per platform. Slots: 12:30pm evergreen, 5:30pm news, 7pm reels. Thursday gets the strongest post.

## Design
- The CarTell brand system: `CLAUDE.md` in the project folder, `brand-guide.html`, the `/brand/` logos and `Brand Systems/MEDIA_ENGINE.md` ("calibrated bolder").
- Gradient #B81FD8 to #E3187C to #F0185C, Ink #0B1220, Sofia 800 italic display.
- The vehicle owns at least 55% of the canvas. Full-resolution press images only: cover-crop, never stretched.

## Hard rules
- **No "VFACTS" in any public copy.** Say "new-car sales figures" or "sales data". The pillar name is internal only.
- Never name rival Australian outlets.
- No AI-generated car imagery passed off as press.
- No dashes as punctuation.
- Every post needs a real vehicle photo (or a labelled concept for the AI formats).
- Every number is sourced and current. A "this week" post uses this week's news.
- Tag the manufacturer's AU account only when the handle has been verified.
