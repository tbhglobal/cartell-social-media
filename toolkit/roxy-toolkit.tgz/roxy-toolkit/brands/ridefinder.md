# Brand brief: RideFinder (part of the Bikes agent)

Reports to Roxy. Load skill `social-design-studio` and read `../BUDGET-RULES.md` first. This brief overrides the RideFinder lines in `bikes.md`.

## Accounts (Dispatch network key `ridefinder`)
- Facebook: RideFinder (1381751358346100)
- Instagram: @ridefinder.au (17841430356989836)
- YouTube @ridefinderau: Ted uploads, Roxy optimises.
- TikTok (ridefinderau): ROXY POSTS via Buffer channel 6abfa43cea19ca0bde534119, one a day at 6:30pm Adelaide, always 7 days queued. Cross post every audited reel from RideFinder, eBikeFinder, BikeFinder and ScootFinder that is not already on the TikTok. Tick Buffer's AI-Generated toggle on any reel with AI scenes. Files must be under 10MB.
- Site: ridefinder.au, including the outing database at ridefinder.au/rides/.

## Positioning (Ted, 26 Sep 2026)
**RideFinder = the Australian ride discovery and two-wheel lifestyle brand.**
- Not primarily about specs, not hardcore cycling, not just e-bikes, not just scooters.
- It answers three questions: Where should I ride? What should I ride there? What can I do this weekend?
- It's travel and weekend content where the bike, e-bike or scooter is how you experience the place.

## The 10 series
**1. FIND A RIDE (signature series):** built from the ridefinder.au outing database. Keep expanding the database: new rides found for social get flagged to Ted for the site.
- Headlines:
  - RIDE THIS WEEKEND
  - 60 MINUTES TO KILL? RIDE THIS.
  - THE PERFECT SUNDAY MORNING RIDE
  - 5KM AND A GOOD COFFEE
  - A RIDE WITH ZERO COMMITMENT
  - THE AFTER-WORK ESCAPE
  - A RIDE THE KIDS CAN ACTUALLY DO
  - A GOOD FIRST E-BIKE RIDE
  - NO LYCRA REQUIRED
- **Every post gives:** location · distance · approximate time · difficulty · surface · road exposure · a good stopping point · suitable ride type.

**2. THE RIDE, NOT THE BIKE:** experiences, not products. Very visual and made for reels.
- BEACH → COFFEE → HOME · VINEYARDS ON TWO WHEELS · RIDE TO LUNCH · SUNSET ROLL · THE 20 MINUTE CITY ESCAPE · THE BEST WAY TO SEE [PLACE] · PARK THE CAR HERE. RIDE THE REST.

**3. SAME JOURNEY. THREE WAYS.:** the same trip by bike, e-bike and scooter.
- Compare: journey time, effort, carrying and storage, charging, hills, practicality and cost.
- The question is always "Which suits this journey?", never "Which is best?"
- Versions:
  - 8km city commute
  - beach run
  - school run
  - train station commute
  - Saturday coffee run
  - 10km into the CBD
- Link out to BikeFinder, eBikeFinder and ScootFinder.

**4. LEAVE THE CAR:** a practical challenge, never preachy environmental content.
- COULD YOU DO THIS TRIP WITHOUT THE CAR? · 3KM TO THE SHOPS. WHAT ARE YOU TAKING? · THE SCHOOL RUN WITHOUT A CAR · DINNER 4KM AWAY · TRAIN STATION 6KM AWAY · ONE WEEK OF SHORT TRIPS WITHOUT DRIVING

**5. RIDE + SOMETHING:** the destination is the reason to ride.
- RIDE + COFFEE / PUB / BEACH / WINERY / PLAYGROUND / BREAKFAST / SWIM / MARKET / PICNIC
- Format example: RIDE + WINE · Shiraz Trail · 16km return · McLaren Vale / Willunga · Lunch halfway.
- **Rules:**
  - Venues are mentioned only if they're verified as open, with a caption mention and no collab invites.
  - Ride + pub and ride + winery posts never imply riding after drinking. Use a light "ride first, taste after" or "take the train home" framing.

**6. HOW FAR CAN YOU GO?:** short video. 10 minutes / 30 minutes / one hour by bike, e-bike or scooter. "You live 8km from work. That's closer than you think."
- **Always state the assumptions on screen:**
  - bike about 15 to 18km/h;
  - e-bike about 20 to 25km/h (the legal assist limit is 25km/h);
  - scooter about 15 to 20km/h, under whatever the state speed limit is;
  - flat route, no stops.

**7. RIDEFINDER FIELD GUIDE:** approachable micro-guides built from the site's own language, never BikeFinder-level technical.
- FIRST RIDE · FIRST COMMUTE · FIRST RAIL TRAIL · FIRST E-BIKE RIDE · RIDING WITH KIDS · TAKING A BIKE ON THE TRAIN · WHAT TO PACK FOR 20KM · WHAT IF YOU GET A FLAT? · HOW MUCH WATER DO YOU NEED?

**8. CAN I RIDE HERE?:** translate the rule into the journey.
- Bike path or footpath? Can an e-scooter use this? Can an e-bike ride here? What does this sign actually mean? What changes when you cross a state border?
- **Always name the state.** Rules are verified against the state transport authority on the day and linked. Detailed law articles belong to eBikeFinder and ScootFinder, so link there.

**9. WORTH RIDING?:** a route review, not a bike review.
- Rate: scenery · traffic stress · surface · coffee and food · family suitability · e-bike suitability · would we ride it again?
- Only rate routes that Ted or the team have actually ridden, or clearly base the rating on the published route data and say so.

**10. RIDE OF THE WEEK:** one location a week, with strong photos or video.
- Card: THE RIDE / WHERE / DISTANCE / TIME / EFFORT / BEST BIT / TAKE.
- Then send people to the full RideFinder guide.

## Left-of-field ideas (use about one a week)
- YOU HAVE 90 MINUTES. WHERE ARE YOU RIDING?
- WOULD YOU RIDE THIS TO WORK EVERY DAY?
- THE PERFECT BIKE PATH DOESN'T EXI…
- AUSTRALIA'S PRETTIEST COMMUTE
- THIS IS A BIKE PATH?!
- THE WORST PART OF THIS RIDE IS ONLY 200 METRES
- HOW FAR WOULD YOU DRIVE TO GO FOR A RIDE?
- YOU CAN ONLY KEEP ONE: BIKE / E-BIKE / SCOOTER
- THE $0 SUNDAY ACTIVITY
- A DATE, BUT ON BIKES
- TAKE YOUR DAD / MUM / KID HERE
- THE RIDE YOU'D SEND A TOURIST ON

## Imagery and AI video
RideFinder is the mobility brand that makes the most of AI lifestyle video (5 to 10 seconds, following the budget rules). Use it for:
- a city transforming from cars to bikes and e-bikes;
- a map route coming alive;
- a sunrise coastal ride;
- city → beach → forest transitions;
- "30 minutes from home";
- three modes appearing for the same trip;
- a commute turning into a weekend adventure;
- an Australia map lighting up with rides;
- an office to trail cut;
- seasons changing on one route.

**Rules:**
- Aspirational is fine because it sells the feeling, but vehicles in AI video stay unbranded, and they never show a fake product as a real model.
- **Real named locations use accurate real imagery where practical:** RideFinder's own footage first, then tourism body or council media libraries that allow editorial use (credited).
- AI never passes itself off as a specific real trail. If AI imagery sits on a named route post, label it "Illustrative image".
- Helmets on every rider. No identifiable children without consent: shoot family rides from behind or at a distance.

## Cadence
- At least one Facebook and Instagram post a day. RIDE OF THE WEEK every Thursday or Friday, ahead of the weekend.
- Weekend-planning posts go out Thursday to Saturday morning.
- YouTube and TikTok: Shorts from our own ride footage when Ted supplies it.

## Hard rules
- Distances, times and surfaces come from the RideFinder listing or the managing trail authority, with the date checked.
- Trail closures are checked before posting.
- No dashes as punctuation.
- No rival Australian outlets named.

## AI label (Ted, 1 Oct 2026, all brands)
AI images and clips carry the disclosure as small (~20px), semi-transparent text "Illustrative, AI generated" at the bottom of the frame. Never a badge or pill over the image. This replaces any earlier "ILLUSTRATIVE IMAGE" badge instruction in this brief.

## Brand tags on every Aventon and Reid post (Ted, 2 Oct 2026)
- Aventon: tag @bikesonline.aus FIRST (BikesOnline, Aventon's exclusive Australian retailer; David asked for the mention), then @aventon (global; no Aventon Australia account). Facebook copy names BikesOnline ("$X ride away through BikesOnline").
- Reid / Let's Moto: tag @reidcycles (Reid Cycles Australia), optional second @reidbikes (Reid Bikes International).
- Instagram: @handles in the caption above the hashtags AND ig_user_tags (reels take usernames only; images get x/y on the bike). Handles verified via Business Discovery 2 Oct 2026.
- TikTok handles (checked 2 Oct 2026): @bikesonline.com (BikesOnline, linked from bikesonline.com.au, 41.6K) and @aventon (verified, 14.6K). Reid: reidcycles.com.au links @reidcycles but TikTok says the account does not exist, so no Reid TikTok tag until one is confirmed.
