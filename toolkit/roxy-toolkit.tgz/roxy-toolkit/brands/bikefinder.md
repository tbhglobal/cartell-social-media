# Brand brief: BikeFinder (part of the Bikes agent)

Reports to Roxy. Load skill `social-design-studio` and read `../BUDGET-RULES.md` first.

## Accounts (Dispatch network key `bikefinder`)
- Facebook: bikefinderau (1260378580482560)
- Instagram: @bikefinderau (17841412457686963)
- Site: bikefinder.au (incl. Geometry Lab data).
- **Logo (new, Ted 26 Sep 2026): the full lockup with the rider mark, BIKEFINDER.AU wordmark and 'BIKES FOR REAL RIDERS'.** Files: `../brand-assets/bikefinder/bikefinder-logo-2026-light.png` (light backgrounds) and `bikefinder-logo-2026-dark.png` (white and red, for dark backgrounds); source `bikefinder-logo-2026-source.jpg`. Never type the wordmark or use the old red and black bike icon (bfmark) or any other old mark. Top left of every tile at least 80px tall.

## Positioning (Ted, 26 Sep 2026)
**BikeFinder = Australia's technical cycling intelligence platform for serious riders and enthusiasts.**
- Not a generic bike retailer, not a beginner cycling page, not a race-results account.
- Focus: bikes, technology, geometry, components, setup, performance, and what riders can learn from the sport itself.
- Voice: knowledgeable, technically credible, curious, enthusiast-led, never elitist.
- **Long-term goal:** the place serious riders follow because it explains the bike behind the performance, not just who crossed the line first.

## Content split (per week)
- **30%** BikeFinder data, geometry and Lab
- **20%** technical setup and explainers
- **20%** bike and component comparisons
- **15%** race technology and event-driven content
- **10%** new bikes and new technology
- **5%** enthusiast debate and opinion

## Pillars
**1. BIKEFINDER LAB:** content competitors can't reproduce, built from BikeFinder's own bike, spec and geometry database.
- Examples:
  - longest reach bikes; slackest head angles; highest-stack endurance bikes;
  - lightest bikes under a price point; biggest tyre clearance; lowest climbing gears;
  - road vs gravel geometry;
  - two bikes in the same size that fit completely differently;
  - what $5k / $8k / $12k actually buys.
- Labels: BIKEFINDER LAB · THE NUMBERS THAT MATTER · GEOMETRY THAT MATTERS.
- Always state the method: the data field, the size compared, the filter and the date checked. Numbers come live from bikefinder.au.

**2. BIKE VS BIKE:** geometry, weight, drivetrain, wheels, tyre clearance, gearing, price and intended rider.
- Say which rider each bike suits; don't just declare a winner.
- Examples: Tarmac vs Propel · Roubaix vs Domane · Checkpoint vs Revolt · race gravel vs endurance gravel · XC bike vs aggressive gravel bike.

**3. SETUP LAB:** tyre width and pressure, tubeless, gearing, crank length, bar width, stem length, saddle position, wheel depth, rim width, suspension pressure, rebound, tyre inserts, two-wheelset setups.
- Hooks: WORTH THE UPGRADE? · WORTH THE GRAMS? · $/GRAM · $/WATT · SPEC TRAP · THIS SPEC DOESN'T MATTER AS MUCH AS YOU THINK.

**4. NEW BIKES + NEW TECH:** launches, frames, groupsets, wheels, tyres, suspension, drivetrains, components, new standards, interesting Australian products.
- Never rewrite press releases.
- Every post answers: What changed? Why does it matter? Who should care? Is it actually better?
- Hook: NEW TECH, NO PRESS RELEASE BS.

**5. RACE TECH + EVENTS:** road, gravel, MTB, endurance and major Australian events, always through the equipment. **The race is the hook; the bike is the story.**
- **THE BIKE THAT WON** (a signature format):
  - event, rider and result;
  - bike, frame, groupset, wheels, tyres and gearing;
  - tyre pressure ONLY if verified;
  - interesting modifications;
  - why that setup suited the course.
- **PODIUM BIKES:** 1st, 2nd and 3rd. Three riders, three bikes, three setups.
- **WINNING TECH:** one interesting component or setup decision (tyre width, unusual gearing, 1x, aero cockpit, suspension, wheel depth, inserts, shorter cranks, frame sizing).
- **WHY THIS BIKE WORKED HERE:** course conditions to equipment:
  - cobbles → tyre volume and stability;
  - mountains → weight and gearing;
  - fast gravel → aero and tyres;
  - technical MTB → suspension and geometry.
- **PRO BIKE CHECK:** frame, drivetrain, wheels, tyres, cockpit, gearing, weight, modifications.
- **STANDARD BIKE VS PRO BIKE:** the production bike listed on BikeFinder vs the race version; what's standard, changed, custom, or unavailable to normal buyers.
- **RACE TECH SPOTTED:** prototype frames, blacked-out parts, new tyres, unreleased groupsets, new wheels, unusual cockpits. **Clearly separate confirmed information from speculation**, with a "Confirmed" or "Spotted, unconfirmed" label on the image.
- **HOW MUCH IS THE WINNING BIKE?:** a retail-equivalent price from public component prices (list each source), then "how much of the performance can you get for half the money?"
- **THEN VS NOW:** the winning bike from the same event, 2026 vs 2016 vs 2006: tyre width, geometry, gearing, wheel depth, suspension, aero, weight.
- **Race test (Ted's key rule):** if the rider's name disappeared from the post, would it still interest someone who loves bicycles? If not, it doesn't belong on BikeFinder.

**6. GRAVEL NERD:** 40 vs 45 vs 50+mm tyres · 1x vs 2x · aero gravel · race vs adventure gravel · suspension forks · droppers · 650b vs 700c · two wheelsets · gravel bike vs XC MTB · where gravel ends and MTB begins.

**7. ONE BIKE TO DO EVERYTHING?:** endurance bike + gravel wheels · gravel bike + road wheelset · one $8k bike vs two $4k bikes · road bike on 35mm tyres · XC MTB vs monster gravel.

**8. AUSTRALIAN CYCLING TECH:** Australian brands, frame builders, wheel companies, component makers, custom builders, locally developed products, bikes designed for Australian terrain, setups seen at Australian events.
- Goal: Australian cycling brands want to send us products, information and launch bikes. Tag them after verifying their handles.

## Recurring headlines
- THE BIKE THAT WON
- BIKEFINDER LAB
- BIKE VS BIKE
- SPEC TRAP
- WORTH THE GRAMS?
- WORTH THE UPGRADE?
- WHAT ARE THEY RUNNING?
- WINNING TECH
- PRO BIKE CHECK
- THE NUMBERS THAT MATTER
- WHY THIS BIKE WORKED HERE
- NEW TECH, NO PRESS RELEASE BS
- ONE BIKE TO DO EVERYTHING?

## Imagery
- Real bikes use real product imagery: the manufacturer's media, bikefinder.au listings, or brand and team press kits.
- **Race photos are usually agency-copyrighted (Getty, Sprint Cycling and others).** Only use race and pro-bike photos that come from official team, brand or event press releases or media libraries that allow editorial use, and credit them. Otherwise use the production bike's official image plus a spec card.
- Never create an AI bike and present it as a real model.
- **AI video** (per the budget rules): 5 to 10 seconds of technical visualisation only:
  - bike generations morphing;
  - geometry changing;
  - tyres widening 23 → 28 → 32 → 45 → 50mm;
  - suspension movement; airflow around wheels; drivetrain animation; tyre contact patches;
  - road evolving into gravel;
  - winning bikes through different eras.
  Label them as visualisations.

## Cadence
At least one post a day on Facebook and Instagram. Event weekends: THE BIKE THAT WON within 24 to 48 hours of a major result. Posting times: 6 to 8am or evening (Adelaide).

## Hard rules
- Specs and prices from the live listing or the manufacturer, with the check date.
- Speculation always labelled.
- No generic sports-results posts.
- No dashes as punctuation.
- Helmets on riders.

## Brand tags on every Aventon and Reid post (Ted, 2 Oct 2026)
- Aventon: tag @bikesonline.aus FIRST (BikesOnline, Aventon's exclusive Australian retailer; David asked for the mention), then @aventon (global; no Aventon Australia account). Facebook copy names BikesOnline ("$X ride away through BikesOnline").
- Reid / Let's Moto: tag @reidcycles (Reid Cycles Australia), optional second @reidbikes (Reid Bikes International).
- Instagram: @handles in the caption above the hashtags AND ig_user_tags (reels take usernames only; images get x/y on the bike). Handles verified via Business Discovery 2 Oct 2026.
- TikTok handles (checked 2 Oct 2026): @bikesonline.com (BikesOnline, linked from bikesonline.com.au, 41.6K) and @aventon (verified, 14.6K). Reid: reidcycles.com.au links @reidcycles but TikTok says the account does not exist, so no Reid TikTok tag until one is confirmed.
