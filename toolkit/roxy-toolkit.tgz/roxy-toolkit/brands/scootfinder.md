# Brand brief: ScootFinder (part of the Bikes agent)

Reports to Roxy. Load skill `social-design-studio` and read `../BUDGET-RULES.md` first. This brief overrides the ScootFinder lines in `bikes.md`.

## Accounts (Dispatch network key `scootfinder`)
- **LIVE in Dispatch since 9 Oct 2026:** Facebook page Scootfinder (1250668384796671) and Instagram @scootfinder (17841447549716027). Two posts a day like every other page (08:30 and 18:00 Adelaide).
- Site: scootfinder.au. Around 84 scooters from 21 brands, state-by-state legality, Australian pricing, real-world range estimates, side-by-side comparisons, and categories from commuter and portable through to performance and off-road. Pull live counts from the site; never hardcode them.

## Positioning (Ted, 26 Sep 2026)
**ScootFinder = Australia's e-scooter reality check.**
- Not another 80km/h account. Not a retailer pushing whatever it stocks.
- It answers:
  - Can I ride it?
  - Can I live with it?
  - How far will it really go?
  - Is it actually worth the money?
- **Our edge:** independent Australian information, verified specs, real-world range, comparisons and state-by-state legality.
- **Franchise line:** FAST IS EASY. GOOD IS HARDER.

**Network lanes (keep them separate):**
- BikeFinder: tell me about the bike.
- eBikeFinder: help me understand and choose an e-bike.
- RideFinder: give me somewhere to ride.
- **ScootFinder: tell me the truth about owning a scooter.**

## Content split
- **30%** practical ownership / Scooter Reality
- **20%** comparisons and the ScootFinder database
- **20%** legality and explainers
- **15%** new products and industry news
- **10%** real-world reviews and tests
- **5%** entertainment, debate and concepts

## The 15 series
**1. SCOOTER REALITY (signature series):** marketing claims vs everyday reality.
- RANGE REALITY (claimed 70km → what to realistically expect)
- THE CARRY TEST ("This scooter weighs 29kg. Now imagine three flights of stairs.")
- THE HILL TEST
- THE COMMUTE TEST
- BOOT TEST
- TRAIN TEST
- BRAKE TEST
- 24 HOURS WITH IT
- COULD YOU ACTUALLY LIVE WITH THIS?
- **Weight is under-discussed, so lead with it.**

**2. LEGAL OR NOT?:** a major franchise. Show a scenario, then reveal the answer.
- Examples:
  - "40km/h scooter. Adelaide bike path. Legal or not?"
  - private scooter in NSW;
  - a 25km/h limiter vs simply riding slowly;
  - footpath use;
  - can a teenager ride it?
- Headline: SAME SCOOTER. DIFFERENT STATE. DIFFERENT ANSWER.
- **Always cite and link the current official state source, checked on the day.** Put the state and "Checked [date]" on the reveal slide.

**3. SPEC CHECK:** decode confusing marketing.
- SPEC DOESN'T MEAN WHAT YOU THINK
- CLAIMED vs REAL
- PEAK POWER vs NOMINAL POWER
- IPX5: WHAT DOES THAT ACTUALLY MEAN?
- 25KM/H CAPABLE ≠ ROAD LEGAL EVERYWHERE
- DUAL MOTOR: DO YOU ACTUALLY NEED IT?
- SOLID vs PNEUMATIC TYRES
- SUSPENSION OR BIGGER TYRES?
- WHY 60KM RANGE ISN'T NECESSARILY 60KM

The goal: the account people send to a friend before they buy.

**4. THE 25KM/H TEST:** what makes a scooter good at legal commuting speed.
- Test: throttle smoothness, braking, stability, steering, suspension, deck, tyres, lighting, indicators, portability.

**5. SCOOTER vs SCOOTER:** 15 to 30 seconds.
- For example: $699 Xiaomi 6 Lite vs $1,599 Segway MAX G3.
- Compare price, weight, real range, suspension, tyres, legal class, and who each suits.
- End with "Compare the full specs at ScootFinder.au".
- Prices come from the live listing on the day.

**6. WHAT $X BUYS:** $500 / $1,000 / $1,500 / $3,000, or $1,000 vs $3,000.
- What genuinely improves? Range, brakes, suspension, build, water resistance, serviceability, battery, weight and comfort. Not just speed.

**7. NEW TO AUSTRALIA:** fast newsroom content.
- JUST LANDED 🇦🇺 · NEW SCOOTER · PRICE DROP · NEW SEGWAY · NEW XIAOMI · AUSTRALIAN PRICE CONFIRMED · RECALL · LAW CHANGE · NEW BRAND TO WATCH · DISCONTINUED
- Always answer "what's actually different?" and never rewrite the press release.
- Recalls are sourced to productsafety.gov.au.

**8. SCOOTER AUTOPSY:** a close technical look.
- Folding mechanism, stem, welds, tyres, brakes, suspension, battery placement, charging port, deck, lighting, water sealing, cable routing.
- Hook: THIS MATTERS MORE THAN ITS TOP SPEED.
- Only with a physical unit in hand (test units from retailers). Never from renders.

**9. FIRST SCOOTER:**
- DON'T BUY YOUR FIRST SCOOTER UNTIL YOU KNOW THESE 5 THINGS
- THE $700 FIRST SCOOTER
- WHAT BEGINNERS ALWAYS OVERLOOK
- HOW MUCH RANGE DO YOU ACTUALLY NEED?
- DO YOU NEED SUSPENSION?
- HOW HEAVY IS TOO HEAVY?
- WHERE WILL YOU CHARGE IT?
- WHERE WILL YOU SERVICE IT?

**10. SCOOTER MYTHS:** short form.
- MORE WATTS = BETTER?
- SOLID TYRES NEVER NEED MAINTENANCE?
- IP RATING MEANS WATERPROOF?
- 25KM/H MEANS LEGAL?
- CLAIMED RANGE IS REAL RANGE?
- DUAL MOTOR IS BETTER FOR EVERYONE?
- BIG BATTERY = LONG RANGE?

**11. COMMUTE MATH:** 5km to work by scooter vs car vs public transport. Compare time, charging cost, parking and ownership considerations. Or: WHEN DOES A $1,200 SCOOTER PAY FOR ITSELF?
- Build from the site's "are electric scooters worth it" guide.
- State every assumption (electricity rate, fuel price, fares) with its source.

**12. SAFETY WITHOUT BECOMING BORING:** practical, never preachy.
- BATTERY RED FLAGS · DON'T CHARGE IT HERE · TYRE PRESSURE MATTERS · WHEN YOUR STEM NEEDS CHECKING · WHY CHEAP CHARGERS MATTER · WHEN TO REPLACE A TYRE · WHAT TO CHECK AFTER A CRASH
- Battery guidance follows fire service and ACCC Product Safety advice, and is cited.

**13. WHO IS THIS ACTUALLY FOR?:** turn specs into a decision.
- For example, the Segway MAX G3: long-distance commuter, no need to carry it upstairs, wants established servicing, values comfort over light weight.

**14. HEAVY RIDER TEST:** acceleration, hills, real range, suspension, deck room and braking at different rider weights, rather than just quoting the payload.
- Only with real units and real riders, done safely.
- Until then, use a data version from manufacturer payload and range figures, clearly labelled as estimates.

**15. RETAILER RADAR:** make Australian retailers and distributors want to work with us.
- Cover: dealer openings, new brands, launch stock, demo days, accessories, events, new model availability. Tag the businesses after verifying their handles.
- Recurring CTA: **GOT SOMETHING NEW? SEND IT TO SCOOTFINDER.** Review scooters, launch units, accessories, model info, pricing changes, embargoed announcements.
- One scooter can become a review, a directory profile, a comparison, a reel, a TikTok, test content and a buyer-guide entry.

## Left-of-field ideas (about one a week)
- WOULD YOU CARRY THIS UP THREE FLIGHTS OF STAIRS?
- YOU GET ONE SCOOTER FOREVER. WHAT MATTERS MOST? (range / weight / comfort / power)
- THIS SCOOTER DOES 100KM/H. BUT WHY? This is a private land and performance discussion only. Always state that it isn't legal on public roads or paths, and never show or encourage illegal public use.
- $500 SCOOTER vs $5,000 SCOOTER
- THE PERFECT SCOOTER DOESN'T EXIST. HERE'S WHY.
- WHAT YOUR SCOOTER SAYS ABOUT YOU
- THE SCOOTER FEATURE I'D BAN
- ONE FEATURE EVERY SCOOTER SHOULD HAVE
- WOULD YOU BUY A SCOOTER WITH NO SUSPENSION?
- THE 20KG PROBLEM
- YOUR SCOOTER CLAIMS 70KM. YOU'RE PROBABLY NOT GETTING 70KM.

## Imagery and AI video
- **Real scooter = real imagery:** manufacturer or distributor media, or the scootfinder.au listing image on pure white.
- **Concepts and explainers:** AI is fine (5 to 10 seconds, following the budget rules). For example:
  - a claimed range bar shrinking under hills, wind and weight;
  - a battery cutaway;
  - a commute through changing cities;
  - 12kg → 20kg → 30kg → 45kg getting harder to carry;
  - solid vs pneumatic tyres;
  - suspension travel;
  - folding into a train, car or office;
  - an Australia map with rules changing by state;
  - scooters from 2015 to 2026 to a future concept.
- AI scooters stay unbranded and are never implied to be a real model. Label them "Illustrative image".
- Helmets on every rider; riders shown at legal speeds on legal infrastructure.

## Cadence
At least one post a day once the pages are linked. Draft this week's posts regardless, so they're ready.

## Hard rules
- **Real-world range and every test claim** comes from ScootFinder's published estimate (with its method) or a test we actually did. Never invent test results.
- **Specs and prices** come from the live listing, with the date checked.
- **Legality:** always state-specific, with the official source cited.
- No dashes as punctuation. No rival Australian outlets named.

## DAILY BASELINE: SCOOTER SH*T YOU SHOULD KNOW (Ted, 30 Sep 2026)
One researched, shareable tile every day. Goal: stop, read, learn, smile, share or comment.
Formula: 1) BIG HOOK (curiosity, never "Understanding electric scooter range") 2) ONE verified interesting fact, very concise 3) the ScootFinder punchline (dry observation).
Categories (rotate hard): Range & batteries; Scooter engineering (explained without being boring); Money; Weird scooter world (records, prototypes, bizarre and historic scooters); Things manufacturers don't tell you (recurring); Scooter culture (data, surveys, trends); New & trending (can replace the day's evergreen tile).
Visual: consistent but not identical template. Big headline readable without opening, strong real scooter image, one key stat, small explanation, small "SCOOTER SH*T YOU SHOULD KNOW" identifier, ScootFinder branding. Never overcrowd.
Caption: hook, 2 to 4 short paragraphs, ScootFinder perspective or joke, end with a question (we want comments).
Research standard: research, verify, simplify, entertain. Manufacturers, government data, research papers, reputable publications, genuine testing. Never invent a stat. Store the source URL in the manifest record.
Tone: curious, funny, useful, slightly chaotic. Mock marketing claims, manufacturers, scooter culture and ourselves; never individual riders. Not a road-law account. Not brochure copy.
Daily workflow: check news, shortlist 3 facts, pick the strongest hook, verify, headline, tile, caption, publish, track (shares, saves, comments, profile visits, clicks) and feed results back into topic choice.
Golden rule: "If I didn't already care about scooters, would this still make me stop scrolling?"
Reels: real motion only. Animate real product or press photography (Kling image to video, check every frame for distortion), or use AI clips for satirical, non-product scenes with a generic unbranded scooter, labelled "Illustrative, AI generated" in small, semi-transparent text at the bottom of the frame (Ted, 1 Oct 2026: keep it subtle, not a pill over the footage), helmets on.
Series name keeps the asterisk: "SH*T" (never spelled out).

## AI label (Ted, 1 Oct 2026, all brands)
AI images and clips carry the disclosure as small (~20px), semi-transparent text "Illustrative, AI generated" at the bottom of the frame. Never a badge or pill over the image. This replaces any earlier "ILLUSTRATIVE IMAGE" badge instruction in this brief.

## Branding on scooter reels (Ted, 7 Oct 2026)
Future scooter reels posted to ScootFinder carry ScootFinder branding (ScootFinder logo bug and a ScootFinder end card), not the RideFinder and eBikeFinder logos or the RideFinder subscribe card. If Ted supplies a scooter reel with the RideFinder/eBikeFinder package, swap the logo bug and end card before posting it to ScootFinder.
