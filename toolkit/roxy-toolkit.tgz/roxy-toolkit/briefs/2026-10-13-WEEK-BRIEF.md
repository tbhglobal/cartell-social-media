# Week brief: Tue 13 Oct to Sun 18 Oct 2026 (all brand agents)

From Roxy. URGENT: most pages have nothing queued. Tuesday 13 Oct 08:30 Adelaide is the first deadline, so build Tuesday first and write manifest.json after EVERY finished post. Roxy audits and queues posts as they land.

Read, in order: this file, `../2026-10-05/WEEK-BRIEF.md` (output format, manifest fields, house rules, QA all still apply), `../2026-09-28/WEEK-BRIEF.md` (production method and the Never list), your brand brief in `_agent_shared/social/brands/`, then the skill `social-design-studio` (section 0 is non-negotiable).

## Slots
- AU brands: am 08:30 Adelaide (22:00 UTC previous day), pm 18:00 Adelaide (07:30 UTC).
- Plate Snob: am 09:00 GST, pm 19:00 GST.
- Default range: Tue 13 Oct am through Sun 18 Oct pm (12 slots). Your prompt lists any slots already taken. Skip those.
- Output folder: `_agent_shared/social/drafts/2026-10-13/<brand>/` with `final/`, `assets/`, `build/`, `manifest.json`, `SUMMARY.md`.

## No repeats
Last week's posts are LIVE. Before choosing any topic, image or clip, read every manifest under `../2026-10-05/<brand>/`, `../2026-09-28/<brand>/` and any other `drafts/2026-10-*` folder for your brand. Never reuse an image, clip, hook or topic from those within 10 days. Ted has caught double posts before and was not happy.

## Video this week
The Artlist generator is NOT available this run. Do not generate AI video or music. Reels only from real footage already in the project (`_agent_shared/social/broll/`, `drafts/2026-10-07-reels/src/`, your brand's previous `assets/`) with an already licensed track from a previous `assets/` folder. If you have no suitable unused real footage, make carousels and tiles instead (aim for at least 3 carousels).

## Audit lessons from last week (each one reached Ted)
- A bike with no handlebars, a scooter rendered as a suitcase, a New York skyline in a Dubai post, a Jeep lookalike in a kids post. Look at every final at FULL SIZE, part by part, before you list it. Bikes: handlebars, stem, fork, wheels, chain, pedals, saddle. Vehicles: whole vehicle, wheels, plates. People: hands, helmets.
- Product shots on pure white (corners 255,255,255) and the whole product in frame.
- Every price, spec and rule verified today on the official or retailer page, with the URL and date in `sources`. If you cannot verify a number today, leave it out.
- No AI image of any real product, venue, dish or place. Generic AI scenes only, with the small "Illustrative, AI generated" line.
- No dashes as punctuation anywhere ("—", "–", " - ").

## Final report
List posts written (day, slot, type, hook), anything unfinished, and open questions. Short.
