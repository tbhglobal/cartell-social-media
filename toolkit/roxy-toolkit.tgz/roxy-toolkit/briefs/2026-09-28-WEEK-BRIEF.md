# Week brief: Mon 28 Sep to Sun 4 Oct 2026 (all brand agents)

From Roxy. Read this, then your brand brief, then the skill `social-design-studio`. Every rule in section 0 of that skill is non-negotiable. Ted has rejected work for each of these:
- drawn pictures;
- stretched photos;
- corrupted images;
- text-only carousels;
- AI images with extra wheel arches or floating objects;
- inconsistent crops.

## Output
- Folder: `_agent_shared/social/drafts/2026-09-28/<brand>/`
  - finals in `final/`
  - working files in `assets/`
  - build scripts in `build/`
- **Minimum 7 posts:** one for each day, Mon 28 Sep to Sun 4 Oct.
  - At least **2 reels** (MP4, 1080x1920) and at least **2 carousels** (4 to 7 slides, 1080x1350).
  - The rest are single images (1080x1350).
  - At least one left-of-field post from your brief's list.
- **`manifest.json`:** an array of posts, one per day. Each post has:
  - `day` (YYYY-MM-DD)
  - `slot_local` (e.g. "07:30 Adelaide" or "19:30 GST")
  - `network_key`
  - `platforms` (["facebook","instagram"])
  - `type` (image | carousel | reel)
  - `series` (from your brief)
  - `hook`
  - `media` (relative paths, in slide order)
  - `cover` (reels only: a still 1080x1920 cover)
  - `caption_instagram`
  - `caption_facebook`
  - `sources` (a URL and checked date for every fact, price and spec)
  - `image_sources` (where each image came from; flag AI images and give the Artlist generationId)
  - `notes_for_roxy` (anything uncertain)
- **Also write `SUMMARY.md`:** a one-line description per post, credits spent, and open questions.

## Calendar beats this week (verify before using)
- NSW, VIC, SA, ACT and TAS school holidays run through this period in most states. Check the dates per state.
- **Daylight saving starts Sunday 4 October** (NSW, VIC, SA, ACT, TAS; not QLD, WA or NT). Longer evenings suit after-work rides, sunset content and "clocks go forward" hooks.
- **Monday 5 October is a public holiday** in NSW, SA and ACT (Labour Day) and in QLD (King's Birthday). That makes it a long weekend: good for weekend rides, road trips and caravan getaways. Verify it first.
- **Motorsport:** check when the Bathurst 1000 is on in 2026 and use it only if it's this week or next.
- **UAE (Plate Snob):** October marks the start of the cooler dining season and outdoor terraces reopening. Check what restaurant openings and events are on this week.
- **Only use news that's actually current.** Search for this week's news, and never present older stories as new.

## Production method
- **Real images first:**
  - manufacturer or press media at full resolution;
  - the brand site's own images;
  - the cartell-tv repo `public/cars/...`.
  After every download, open the image and look at it.
- **Artlist** (tools `mcp__b95d755e-...__generate_image` / `generate_video` / `search_music`):
  - Images: Nano Banana 2 Lite by default. Fix with image-to-image edits (`input: {generationId}`).
  - Video: Seedance 2.0 Mini by default, 5 to 10 seconds.
  - **Credit cap: 3,000 credits for your whole brand this week.** Check the cost with `get_generation_cost` before generating video.
- **Downloading generated or remote files:** the sandbox can't reach Artlist, Canva or many press CDNs. Use Desktop Commander `start_process` on Ted's Mac, for example:
  `curl -L -o "/Users/tedboulhosn/Documents/Claude/Projects/CarTell.tv/_agent_shared/social/drafts/2026-09-28/<brand>/assets/x.jpg" "<url>"`
  That path appears in the sandbox at `/sessions/eager-bold-johnson/mnt/CarTell.tv/_agent_shared/social/drafts/2026-09-28/<brand>/assets/x.jpg`. For Artlist images, use the imgix thumbnailUrl with `w=1280`.
- **Building:**
  - Python PIL in the sandbox. Fonts are in `/usr/share/fonts/truetype/google-fonts/` (Poppins; no Poppins-ExtraBold). Plate Snob fonts are in `drafts/2026-09-26-platesnob/fonts/`.
  - Cover-crop only, never stretch. See `drafts/2026-09-25-samples/caravanscout/v2/build.py` for cover(), fade() and the photo-plus-panel layout that Ted approved.
- **Reels:** ffmpeg in the sandbox.
  - Burned-in text by 0.5s, cuts every 1.5 to 3s, 15 to 30s total, H.264 and AAC, under 20MB.
  - Music: an Artlist licensed track (`search_music`), downloaded via Desktop Commander. If you can't get licensed audio, deliver it silent and flag it. Never use unlicensed audio.
  - A reel can be real footage or photos with motion (a slow push-in on real press images), or AI concept video that your brief allows.
  - Make a still cover for each reel.
- **Logos:** use the real logo files from the samples folders or the brand site. Never type out an imitation.

## QA before you finish
- Open EVERY final image, and three frames of each reel, at full size.
- Tick the checklist in skill section 8.
- Search your captions and on-image text for "—", "–" and " - ". Zero allowed.

## Never
- Never queue, schedule or publish anything, and never touch Dispatch or Supabase.
- Never spend money beyond the Artlist credit cap.
- Never name rival Australian outlets.
- No VFACTS in CarTell reader copy.
- Never AI-generate a real product, venue or dish and present it as real.
- Helmets on every rider.
- No identifiable children.
