# Week brief: Mon 5 Oct to Sun 11 Oct 2026 (all brand agents)

From Roxy. Ted wants every page planned and built **7 days ahead, two posts a day**. Read this file, then `../2026-09-28/WEEK-BRIEF.md` (production method, manifest fields and the "Never" list still apply), then your brand brief in `_agent_shared/social/brands/`, then the skill `social-design-studio`. Section 0 of that skill is non-negotiable.

## Slots (daylight saving started 4 Oct, Adelaide is UTC+10:30)
- AU brands: **am 08:30 Adelaide** (22:00 UTC the previous day) and **pm 18:00 Adelaide** (07:30 UTC).
- Plate Snob: **am 09:00 GST** (05:00 UTC) and **pm 19:00 GST** (15:00 UTC).
- 14 slots: Mon 5 Oct am through Sun 11 Oct pm. Your prompt lists any slots already taken. Skip those.
- Hard cap: two posts a day per page. Never the same image twice on one page within 10 days. Check `../2026-09-28/<brand>/final` and everything published last week so you do not repeat a photo or a topic.

## Output
- Folder: `_agent_shared/social/drafts/2026-10-05/<brand>/` with `final/`, `assets/`, `build/`, `manifest.json`, `SUMMARY.md`.
- `manifest.json` is an array of posts. Add a `slot` field ("am" or "pm") next to `day`. The fields are otherwise the same as last week (day, slot, network_key, platforms, type, series, hook, media, cover, caption_instagram, caption_facebook, sources, image_sources, notes_for_roxy).
- **Work in day order and rewrite manifest.json after EVERY finished post.** Roxy queues posts as they land, so Monday's posts are urgent and Sunday's can wait. If you run out of time, a complete, perfect Monday to Thursday beats a sloppy full week.
- **Mix for 14 posts:** at least 2 reels (real motion, licensed Artlist music, transition into the end card), at least 4 carousels (3 to 7 slides, a different real image on every slide), the rest single tiles. At least one left-of-field post. Aim for depth over filler.
- Single tiles and carousels at 1080x1350 JPG quality 90. Reels at 1080x1920 H.264 + AAC under 15MB (jsdelivr's limit is 20MB) with a 1080x1920 cover.

## Reuse before you make new
Last week's folder `../2026-09-28/<brand>/final/` has unposted work. `../2026-09-28/REVISIONS-ROUND-1.md` says what was wrong with it. You may fix and reuse anything that is still current, but only if the fix is complete. Anything superseded, stale or with a picture that does not match its words, leave it.

## Calendar beats this week (verify each before using)
- Mon 5 Oct is a public holiday in NSW, SA, ACT (Labour Day) and QLD (King's Birthday). Long weekend tail.
- First full week of daylight saving: longer evenings, after-work rides, sunsets.
- School holidays end in several states around now. Check per state. Back-to-school commute angles for the bike brands.
- Bathurst 1000: check the 2026 date. Use it only if it falls this week or next.
- Only use news that is actually current. Search for this week's news and never present older stories as new.

## House rules (Ted, recent)
- No long dashes or en dashes anywhere, and no hyphens used as punctuation. Search your text for "—", "–" and " - ".
- AI images: allowed only for generic unnamed scenes and concepts. Label them with the subtle line "Illustrative, AI generated" (about 20px, 40 to 50% opacity, bottom left). Never a badge.
- Never AI generate a real product, venue, dish or recognisable place.
- Helmets on every rider. No identifiable children.
- Product images on pure white or a real photo. Whole product in frame.
- Tag brands with verified handles only (see your brand brief). Aventon posts: @bikesonline.aus first, then @aventon. Reid: @reidcycles.
- Artlist credit cap this week: **1,500 credits per brand**. Check `get_generation_cost` before any video.
- Never queue, schedule or publish. Never touch Supabase or Dispatch.

## QA before you finish each post
Open every final at full size, and 3 frames of each reel. Tick the skill's section 8 checklist. Then run `python3 _agent_shared/social/tools/qa_check.py _agent_shared/social/drafts/2026-10-05` (from the CarTell.tv folder) and fix every FAIL for your brand.

## Final report (your last message to Roxy)
A list of posts written (day, slot, type, hook), anything you could not finish, credits spent, and open questions. Keep it short.
