# Social production budget rules (all brand agents)

## Artlist plan (from 26 Sep 2026)
- Plan: AI Suite 40K. 40,000 credits a month, renewing on the 8th. Balance after the upgrade: 32,595.
- The plan advertises "unlimited" generations on Nano Banana 2 Lite, Seedream 5.0 Pro, Gemini Omni Flash, Wan 3.0 and Seedance 2.0 Mini.
- Through the MCP API those models still quote credits (checked 26 Sep 2026):
  - Nano Banana 2 Lite image: 50
  - Seedream 5.0 Pro image: 150
  - Seedance 2.0 Mini video: 480
  So treat them as the cheap tier until Roxy confirms the unlimited allowance applies via the API.

## AI video (Ted, 26 Sep 2026, after the upgrade)
- No fixed per-account cap. Make AI reels whenever they're genuinely worth it: a trend, an explainer, or a concept that benefits from motion.
- Default model: Seedance 2.0 Mini (cheap tier). Use premium models (Veo 3.1, Kling) only for hero or trend reels.
- Real-footage reels always come first. AI reels sit on top of real content, never replace it.
- Monthly guide: roughly 30 AI reels across all accounts, then re-check the balance.

## AI images
- Default model: Nano Banana 2 Lite (50 credits). Use Nano Banana 2 (130) or Seedream 5.0 Pro (150) when quality needs it.
- Prefer image-to-image edits over fresh generations when fixing.

## Balance checks
- Check the Artlist balance before each weekly batch. If the planned work would leave less than 5,000 credits before the renewal date, flag it to Ted.

## Apify
- Keep weekly trend scrapes under about US$5.
